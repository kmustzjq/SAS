# News

## 0.1.1
* Changes in the documentation

## 0.1.0 Initial Release
